A Pen created at CodePen.io. You can find this one at https://codepen.io/ItamarRosenblum/pen/gzVMVp.

 Iv'e created shopping list, with JavaScript and dom manipulation.