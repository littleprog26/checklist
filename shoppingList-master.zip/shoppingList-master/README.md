# shoppingList
simple shoppinglist with plain javascript
